#!/bin/sh

echo "Résultat des tests" > results-quantization
for f in test-?{,?}.pgm; do
    ps=$(grep "PaletteSizes" "$f" | cut -d : -f 2)
    if [ -z "$ps" ] ;
    then
        fps="$f"
    else
        fps="$f:$ps"
    fi
    java ImageQuantizationTester "$fps" 2>> results-quantization
done

java ImageQuantizationTester {baboon,lena}_gray.pgm 2>> results-quantization

cat results-quantization
