import fr.univlille.media.*;

// Canevas à remplir

public class LossyGreyQuantizer {
    /**
     * Retourne un tableau indiquant, pour chaque couleur de la
     * palette, le nombre de pixel de l'image de cette couleur
     *
     * @param img image à traiter
     */
    public static int[] histogram(IndexedGreyImage img) {
        return new int[0];
    }

    /**
     * Calcule le niveau de gris idéal pour minimiser l'erreur globale
     * si on fusionne tous les niveaux de gris compris entre start et
     * end dans la palette
     *
     * @param palette    palette de l'image
     * @param histogram  histogramme de l'image
     * @param start      premier indice (inclus) de niveau de gris à traiter
     * @param end        dernier indice (inclus) de niveau de gris à traiter
     */
    public static int intervalIdealGrey(int[] palette, int[] histogram, int start, int end) {
        return 0;
    }

    /**
     * Calcule l'erreur obtenue en remplaçant tous les niveaux de gris
     * compris entre start et end par le niveau de gris idéal
     *
     * @param palette    palette de l'image
     * @param histogram  histogramme de l'image
     * @param start      premier indice (inclus) de niveau de gris à traiter
     * @param end        dernier indice (inclus) de niveau de gris à traiter
     */
    public static int intervalError(int[] palette, int[] histogram, int start, int end) {
        return 0;
    }


    /**
     * Calcule une nouvelle image ayant une palette de targetPaletteSize niveaux
     * de gris et qui ait la plus petite erreur possible avec l'image d'origine
     *
     * @param img                image d'origine
     * @param targetPaletteSize  taille de la palette de l'image produite
     */
    public static IndexedGreyImage quantizer(IndexedGreyImage img, int targetPaletteSize) {
        return null;
    }
}

