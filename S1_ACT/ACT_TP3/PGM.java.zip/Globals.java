//Globals.java

import java.lang.*;
import java.io.*;
import javax.swing.filechooser.*;

public class Globals
{
	public static int BackGround=0,ForeGround=255;
	public static int NW=0,N=1,NE=2,E=3,SE=4,S=5,SW=6,W=7;
}
